#!/bin/bash
# ONE 安装脚本 — 双击运行即可安装
# 支持两种布局：
#   1) 同目录有 ONE.app（DMG 挂载后）
#   2) 同目录有 ONE-*.dmg（ZIP 解压后）
# 若 macOS 提示「无法验证开发者」：右键此文件 → 打开
clear
echo "=============================="
echo "   ONE 安装程序"
echo "=============================="
echo ""

APP_NAME="ONE"
INSTALL_DIR="/Applications"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VOLUME_PATH=""
MOUNTED_BY_US=0

cleanup() {
  if [ "${MOUNTED_BY_US}" = "1" ] && [ -n "${VOLUME_PATH}" ]; then
    hdiutil detach "${VOLUME_PATH}" -quiet 2>/dev/null || true
  fi
}
trap cleanup EXIT

find_app_source() {
  if [ -d "${SCRIPT_DIR}/${APP_NAME}.app" ]; then
    APP_SRC="${SCRIPT_DIR}/${APP_NAME}.app"
    return 0
  fi

  local dmg
  dmg=$(ls -t "${SCRIPT_DIR}"/${APP_NAME}-*.dmg 2>/dev/null | head -1)
  if [ -z "${dmg}" ]; then
    return 1
  fi

  echo "▶ 发现安装包: $(basename "${dmg}")"
  echo "▶ 去除隔离属性..."
  xattr -cr "${dmg}" 2>/dev/null || true

  echo "▶ 挂载安装包..."
  local mount_output
  mount_output=$(hdiutil attach "${dmg}" -nobrowse -quiet 2>&1) || true
  VOLUME_PATH=$(echo "${mount_output}" | grep "/Volumes/" | awk -F'\t' '{print $NF}' | head -1)
  if [ -z "${VOLUME_PATH}" ]; then
    VOLUME_PATH=$(ls -d /Volumes/ONE* 2>/dev/null | head -1)
  fi
  if [ -z "${VOLUME_PATH}" ] || [ ! -d "${VOLUME_PATH}/${APP_NAME}.app" ]; then
    echo "❌ 挂载失败或未找到 ${APP_NAME}.app"
    return 1
  fi
  MOUNTED_BY_US=1
  APP_SRC="${VOLUME_PATH}/${APP_NAME}.app"
  return 0
}

if ! find_app_source; then
  echo "❌ 未找到 ${APP_NAME}.app 或 ${APP_NAME}-*.dmg"
  echo "   请确保本脚本与安装包在同一文件夹。"
  echo ""
  read -p "按回车键退出..." -r
  exit 1
fi

if pgrep -x "${APP_NAME}" > /dev/null 2>&1; then
  echo "▶ 关闭正在运行的 ${APP_NAME}..."
  killall "${APP_NAME}" 2>/dev/null || true
  sleep 1
fi

echo "▶ 安装 ${APP_NAME} 到 ${INSTALL_DIR}..."
rm -rf "${INSTALL_DIR}/${APP_NAME}.app"
cp -R "${APP_SRC}" "${INSTALL_DIR}/${APP_NAME}.app"

echo "▶ 去除安全限制（避免「无法验证开发者」）..."
xattr -cr "${INSTALL_DIR}/${APP_NAME}.app" 2>/dev/null || true

echo ""
echo "✅ 安装完成！"
echo ""

read -p "是否立即启动 ${APP_NAME}？[Y/n] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Nn]$ ]]; then
  open "${INSTALL_DIR}/${APP_NAME}.app"
fi
